"""Headless analysis pipeline."""
